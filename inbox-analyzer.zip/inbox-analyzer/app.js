require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { exec } = require('child_process'); // For auto-opening browser
const app = express();

// ======================
//  Middleware Setup
// ======================
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// ======================
//  View Engine Setup
// ======================
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ======================
//  Routes
// ======================

// Home Page
app.get('/', (req, res) => {
    res.render('index');
});

// Analyze Scam Message
app.post('/analyze', async (req, res) => {
    try {
        const { message } = req.body;
        const detectedLinks = detectLinks(message);
        const isSuspicious = checkLinkSuspiciousness(detectedLinks);
        const analysis = await analyzeMessageWithAI(message);
        
        res.render('results', {
            originalMessage: message,
            analysis: {
                ...analysis,
                detectedLinks,  // Now properly nested
                isSuspicious   // Now properly nested
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).render('index', { 
            error: 'Analysis failed. Please try again.' 
        });
    }
}); 

// ======================
//  Helper Functions
// ======================

function detectLinks(text) {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.match(urlRegex) || [];
}

function checkLinkSuspiciousness(links) {
    const suspiciousPatterns = [
        'bit.ly', 'tinyurl', 'free-gift', 
        'bank-verify', 'secure-login',
        /https?:\/\/[^\/]+\.(ru|xyz|tk)/i
    ];
    
    return links.some(link => 
        suspiciousPatterns.some(pattern => 
            typeof pattern === 'string' 
                ? link.includes(pattern) 
                : pattern.test(link)
        )
    );
}

async function analyzeMessageWithAI(message) {
    // Mock analysis - REPLACE WITH REAL API CALL IN PRODUCTION
    return {
        rewrittenMessage: `This message is pretending to be from a trusted organization and trying to trick you into clicking a malicious link that would steal your personal information.`,
        intent: "Phishing for personal data",
        confidence: "High (90%)",
        tips: [
            "Do not click any links in the message",
            "Contact the organization directly using official channels",
            "Check for spelling/grammar mistakes",
            "Look for urgent/scare tactics common in scams"
        ]
    };
}

// ======================
//  Server Startup
// ======================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    
    // Auto-open browser (Windows) - Remove if not needed
    exec(`start http://localhost:${PORT}`);
})
.on('error', (err) => {
    console.error('Server failed to start:', err);
});