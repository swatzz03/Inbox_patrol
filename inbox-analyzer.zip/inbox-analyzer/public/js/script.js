document.addEventListener('DOMContentLoaded', function() {
    // 1. Warn before visiting suspicious links
    document.querySelectorAll('.link-section.suspicious a').forEach(link => {
        link.addEventListener('click', function(e) {
            if (!confirm('WARNING: This link has been flagged as potentially dangerous. Are you sure you want to proceed?')) {
                e.preventDefault();
            }
        });
    });

    // 2. Handle scam reporting
    const reportBtn = document.querySelector('.report-btn');
    if (reportBtn) {
        reportBtn.addEventListener('click', function() {
            // In a real app, this would send data to your backend
            const originalMessage = document.querySelector('.original-message .message-box').textContent;
            
            console.log('Reported scam:', originalMessage);
            alert('Thank you for reporting this scam!\nOur security team will investigate it.');
            
            // Optional: Add visual feedback
            this.textContent = 'Reported ✓';
            this.style.backgroundColor = '#4CAF50';
            setTimeout(() => {
                this.textContent = 'Report This Scam';
                this.style.backgroundColor = '';
            }, 2000);
        });
    }

    // 3. Enhance link visibility for suspicious links
    const suspiciousLinks = document.querySelectorAll('.link-section.suspicious a');
    suspiciousLinks.forEach(link => {
        link.style.fontWeight = 'bold';
        link.addEventListener('mouseover', () => {
            link.style.textDecoration = 'underline wavy red';
        });
        link.addEventListener('mouseout', () => {
            link.style.textDecoration = '';
        });
    });
}); 